﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multiplication
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int row;
            int col;

            for(row = 1; row <= 10; row++)
            {
                for (col = 1; col <= 10; col++)
                {
                    Console.Write(row * col + "\t");
                }
                Console.WriteLine();
            }

            Console.ReadLine();
        }
    }
}
